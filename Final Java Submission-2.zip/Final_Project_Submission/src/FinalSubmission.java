import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class FinalSubmission {

    private static String DATABASE = "/C:/Users//Admin/Documents/OSU/DB Checkpoints/Checkpoint 3/Checkpoint4.db";

    public static Connection conn = null;

    private static PreparedStatement ps;

    private static void addEmployee(BufferedReader input) {

        try {

            System.out.println("Enter SSN: ");
            String ssn = input.readLine();

            System.out.println("Enter new employee number: ");
            int empNum = Integer.parseInt(input.readLine());

            System.out.println("Enter tenure: ");
            int tenure = Integer.parseInt(input.readLine());

            System.out.println("Enter salary: ");
            int salary = Integer.parseInt(input.readLine());

            System.out.println("Enter name: ");
            String name = input.readLine();

            System.out.println("Enter performance rating: ");
            int performance = Integer.parseInt(input.readLine());

            System.out.println("Enter email: ");
            String email = input.readLine();

            System.out.println("Enter position of employee: ");
            String positionName = input.readLine();

            try {
                String sql = "INSERT INTO Employee (employee_no, SSN, Name, Email, Tenure, Salary, Performance, pos) VALUES (?,?,?,?,?,?,?,?)";
                ps = conn.prepareStatement(sql);

                ps.setInt(1, empNum);
                ps.setString(2, ssn);
                ps.setString(3, name);
                ps.setString(4, email);
                ps.setInt(5, tenure);
                ps.setInt(6, salary);
                ps.setInt(7, performance);
                ps.setString(8, positionName);

                int rowsIn = ps.executeUpdate();
                if (rowsIn > 0) {
                    System.out.println("New employee successfully inserted!");
                }

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    private static void deleteEmployee(BufferedReader input) {
        System.out.println("Enter Employee ID of employee to be deleted: ");
        int deleteID = 0;

        try {
            deleteID = Integer.parseInt(input.readLine());

            try {
                String sql = "DELETE FROM Employee WHERE employee_no= ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, deleteID);
                int rowNum = ps.executeUpdate();

                if (rowNum > 0) {
                    System.out.println("Employee successfully deleted");
                }

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    private static void editEmployee(BufferedReader input) {

        try {
            System.out.println("Enter the number of the emplyee you want to edit: ");
            int id = Integer.parseInt(input.readLine());

            Boolean isDone = false;

            while (!isDone) {
                System.out.println("1. Employee Number");
                System.out.println("2. SSN");
                System.out.println("3. Name");
                System.out.println("4. Email");
                System.out.println("5. Tenure");
                System.out.println("6. Salary");
                System.out.println("7. Performance");
                System.out.println("8. Position");
                System.out.println(
                        "Enter the number of the attribute you want to edit or press 0 to stop: ");

                int index = Integer.parseInt(input.readLine());

                if (index == 1) {
                    System.out.println("Enter new Employee Number: ");
                    int empNum = Integer.parseInt(input.readLine());
                    String sql = "UPDATE Employee SET employee_no=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, empNum);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee number changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    id = empNum;

                } else if (index == 2) {
                    System.out.println("Enter new SNN: ");
                    String ssn = input.readLine();

                    String sql = "UPDATE Employee SET SSN=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, ssn);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee SSN changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 3) {
                    System.out.println("Enter new Name: ");
                    String name = input.readLine();

                    String sql = "UPDATE Employee SET Name=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, name);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee name changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 4) {
                    System.out.println("Enter new Email: ");
                    String email = input.readLine();
                    String sql = "UPDATE Employee SET Email=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, email);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee Email changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 5) {
                    System.out.println("Enter new Tenure: ");
                    int tenure = Integer.parseInt(input.readLine());

                    String sql = "UPDATE Employee SET Tenure=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, tenure);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee Tenure changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 6) {
                    System.out.println("Enter new Salary: ");
                    int salary = Integer.parseInt(input.readLine());

                    String sql = "UPDATE Employee SET Salary=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, salary);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee Salary changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 7) {
                    System.out.println("Enter new Performance: ");
                    int performance = Integer.parseInt(input.readLine());

                    String sql = "UPDATE Employee SET Performance=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setInt(1, performance);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee Performance changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 8) {
                    System.out.println("Enter new Position: ");
                    String position = input.readLine();

                    String sql = "UPDATE Employee SET pos=? WHERE employee_no=?";

                    try {
                        ps = conn.prepareStatement(sql);
                        ps.setString(1, position);
                        ps.setInt(2, id);

                        int rowsIn = ps.executeUpdate();
                        if (rowsIn > 0) {
                            System.out.println("Employee Position changed!");
                        }
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }

                } else if (index == 0) {
                    isDone = true;

                }

            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    private static void searchEmployee(BufferedReader input) {

        System.out.println("Input Employee number (or 'x' to quit): ");
        String id = "";
        try {
            id = input.readLine();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        String sql = "";

        if (!id.equals("x") || !id.trim().isEmpty()) {
            sql = "SELECT * FROM Employee WHERE employee_no=? ";
        }

        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        sqlQuery(conn, ps);

    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows: this query is written with
     *            the PrepareStatement class, typically used for dynamic SQL
     *            SELECT statements.
     */
    public static void sqlQuery(Connection conn, PreparedStatement sql) {
        try {
            ResultSet rs = sql.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void CustTotalItems(BufferedReader cin) {
        System.out.println("Report: Total item interactions per customer");

        String sql = "SELECT Account_no, COALESCE(CompanyName, PersonName) AS Name, COUNT(cus_account) AS NumberOfInteractions FROM Customer JOIN Orders ON Account_no = cus_account GROUP BY Account_no ORDER BY NumberOfInteractions DESC";

        try {
            ps = conn.prepareStatement(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        sqlQuery(conn, ps);
    }

    private static void TopItem(BufferedReader cin) {
        System.out.println("Report: Most popular items");

        String sql = "SELECT ProductID, type, color, COUNT(order_number) AS InteractionCount FROM Product JOIN Orders ON order_number = Order_no GROUP BY ProductID ORDER BY order_number DESC";

        try {
            ps = conn.prepareStatement(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        sqlQuery(conn, ps);
    }

    private static void TopManufacturer(BufferedReader cin) {
        System.out.println("Report: Most popular manufacturers");

        String sql = "SELECT Manufacturer, COUNT(order_number) AS InteractionCount FROM Product JOIN Orders ON order_number = Order_no GROUP BY Manufacturer ORDER BY order_number DESC";

        try {
            ps = conn.prepareStatement(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        sqlQuery(conn, ps);
    }

    public static void main(String[] args) {

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int response = -1;

        String url = "jdbc:sqlite:" + DATABASE;

        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("There was a problem connecting to the database.");
        }

        //Main menu
        while (response != 0) {
            System.out.println("Main Menu:");
            System.out.println("1. Customers");
            System.out.println("2. Employees");
            System.out.println("3. Orders");
            System.out.println("4. Positions");
            System.out.println("5. Departments");
            System.out.println("6. Useful Reports.");
            System.out.println(
                    "Please enter the number of the submenu you would like to go to, or press 0 to quit:");
            try {
                response = Integer.parseInt(in.readLine());

                int userInput = -1;
                if (response == 1) {

                    while (userInput != 5) {
                        System.out.println("Customer Submenu");
                        System.out.println("1. Add new Customer");
                        System.out.println("2. Search Customer");
                        System.out.println("3. Delete Customer");
                        System.out.println("4. Edit Customer");
                        System.out.println("5. Back to Main Menu");
                        userInput = Integer.parseInt(in.readLine());
                    }

                } else if (response == 2) {
                    while (userInput != 5) {

                        System.out.println("Employee Submenu");
                        System.out.println("1. Add new Employee");
                        System.out.println("2. Search Employee");
                        System.out.println("3. Delete Employee");
                        System.out.println("4. Edit Employee");
                        System.out.println("5. Back to Main Menu");

                        userInput = Integer.parseInt(in.readLine());

                        if (userInput == 1) {
                            addEmployee(in);

                        } else if (userInput == 2) {
                            searchEmployee(in);

                        } else if (userInput == 3) {
                            deleteEmployee(in);

                        } else if (userInput == 4) {
                            editEmployee(in);

                        }
                    }
                } else if (response == 3) {
                    System.out.println(
                            "Would you like to search or create an order? 1 for create, 2 for search");
                    userInput = Integer.parseInt(in.readLine());
                    if (userInput == 1) {
                        System.out.println("Enter order details to create order");
                        System.out.println("Enter order num");
                        int order = Integer.parseInt(in.readLine());
                        System.out.println("Enter cust account");
                        String Caccount = in.readLine();
                        System.out.println("Enter distribution center");
                        String dist = in.readLine();
                        System.out.println("Enter delivery_date");
                        String deliver = in.readLine();
                        System.out.println("Enter quantity");
                        int qty = Integer.parseInt(in.readLine());
                        System.out.println("Enter office");
                        String office = in.readLine();
                        String sql = "INSERT INTO Orders(Order_no, cus_account, distribution_no, delivery_date, qty, office_no) VALUES(?, ?, ?, ?, ?, ?)";

                        PreparedStatement stmt = null;
                        try {
                            stmt = conn.prepareStatement(sql);
                            stmt.setInt(1, order);
                            stmt.setString(2, Caccount);
                            stmt.setString(3, dist);
                            stmt.setString(4, deliver);
                            stmt.setInt(5, qty);
                            stmt.setString(6, office);
                            System.out.println("Order added");
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                            System.out.println("There was a problem with the statement");
                        }

                        sqlQuery(conn, stmt);
                    } else if (userInput == 2) {
                        String sql = "SELECT Order_no, cus_account, delivery_date, qty FROM Orders WHERE Order_no = ?";
                        System.out.println("Insert Order num");
                        int order = Integer.parseInt(in.readLine());
                        PreparedStatement stmt = null;
                        try {
                            stmt = conn.prepareStatement(sql);
                            stmt.setInt(1, order);
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                            System.out.println("There was a problem with the statement");
                        }
                        System.out.println("Search results:");
                        sqlQuery(conn, stmt);
                    }

                } else if (response == 4) { //stats search by position
                    System.out.println("Which position?");
                    String pos = in.readLine();

                    String sql = "SELECT pos, Name, Salary, email, Performance FROM Employee WHERE pos = ?;";
                    PreparedStatement stmt = null;
                    try {
                        stmt = conn.prepareStatement(sql);
                        stmt.setString(1, pos);
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                        System.out.println("There was a problem with the statement");
                    }
                    System.out.println("Search results:");
                    sqlQuery(conn, stmt);
                } else if (response == 5) { //stats search by department
                    System.out.println("Which department?");
                    String dep = in.readLine();

                    String sql = "SELECT name, pos, salary, email, Performance FROM Employee LEFT JOIN Position ON pos = pos_name WHERE pos_dept = ?;";
                    PreparedStatement stmt = null;
                    try {
                        stmt = conn.prepareStatement(sql);
                        stmt.setString(1, dep);
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                        System.out.println("There was a problem with the statement");
                    }
                    System.out.println("Search results:");
                    sqlQuery(conn, stmt);
                } else if (response == 6) {
                    while (userInput != 0) {
                        System.out.println("Useful reports: ");
                        System.out.println("1. Total item interactions per customer");
                        System.out.println("2. Most popular item");
                        System.out.println("3. Most used manufacturer");
                        System.out
                                .println("Enter numerical selection or enter 0 to leave");
                        userInput = Integer.parseInt(in.readLine());

                        if (userInput == 1) {
                            CustTotalItems(in);
                        } else if (userInput == 2) {
                            TopItem(in);
                        } else if (userInput == 3) {
                            TopManufacturer(in);
                        }
                    }

                }
            } catch (IOException e) {
                System.out.println("Input Error ");

            }

        }

        System.out.println("Program quit");

        try {
            in.close();
        } catch (IOException e) {
            System.out.println("Input Stream closing error");

        }

        try {
            conn.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

    }

}
